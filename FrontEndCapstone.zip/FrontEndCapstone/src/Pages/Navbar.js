import { Link } from "react-router-dom";
import "./capstoneproject.css";

export default function Navbar() {
  return (
    <div>
      <nav class="navbar navbar-expand-lg">
        <div class="collapse navbar-collapse " id="navbarNavAltMarkup">
          <div class="navbar-nav">
            <div class="d-inline-flex">
              <Link to="/" class="anil">
                <a class="nav-item nav-link active" href="#">
                  Medicare{" "}
                </a>
              </Link>
              <Link to="/About" class="anil">
                <a class="nav-item nav-link active" href="#">
                  About
                </a>
              </Link>
              <Link to="/Contact" class="anil">
                <a class="nav-item nav-link active" href="#">
                  Contact
                </a>
              </Link>
              <Link to="/Viewproducts" class="anil">
                <a class="nav-item nav-link active" href="#">
                  Viewproducts
                </a>
              </Link>
              {/* <Link to="/manageproducts" class="anil">
                <a class="nav-item nav-link active" href="#">
                  manageproducts
                </a>
              </Link> */}

            </div>

            <div class="second-one">
            <Link to="/Admin" class="anil">
                <a class="nav-item nav-link active" href="#">
                  Admin
                </a>
              </Link>
              <Link to="/Signup" class="anil">
                <a class="nav-item nav-link active" href="#">
                  Signup
                </a>
              </Link>
              <Link to="/Login" class="anil">
                <a class="nav-item nav-link active" href="#">
                  Login
                </a>
              </Link>
            </div>
          </div>
        </div>
      </nav>
    </div>
  );
}
