import contact from "./images/contactsuccess.jpg"
function Contacts(){
    return(
        <div class="csuccess">
        <br></br>
        <br></br>
        <h5>CONTACT DETAILS SUBMITTED SUCCESSFULLY</h5>
        <img src={contact} alt="image" width="400" height="400"/>
        </div>
    )
}
export default Contacts;