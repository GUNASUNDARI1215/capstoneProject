import React from "react";
import axios from "axios";
import { Link } from "react-router-dom";
export default class Viewproducts extends React.Component {
  state = {
    posts: [],
  };

  componentDidMount() {
    axios.get(`http://localhost:8080/health/getAll`).then((res) => {
      const posts = res.data;
      this.setState({ posts });
    });
  }

  deleteRow(id, e) {
    axios
      .delete(`https://jsonplaceholder.typicode.com/posts/${id}`)
      .then((res) => {
        console.log(res);
        console.log(res.data);

        const posts = this.state.posts.filter((item) => item.id !== id);
        this.setState({ posts });
      });
  }

  render() {
    return (
      <div class="bg">
        <h2 class="f"> TOTAL PRODUCTS </h2>
        <br></br>

        <input placeholder="search"></input>

        <table className="table table-bordered">
          <thead>
            <tr>
              <th>ID</th>
              <th>MEDICINENAME</th>
              <th>BRANDNAME</th>
              <th>PRICE</th>
              {/* <th>QUANTITY</th> */}
              <th>ACTION</th>  
            </tr>
          </thead>

          <tbody>
            {this.state.posts.map((post) => (
              <tr>
                <td>{post.id}</td>
                <td>{post.medicineName}</td>
                <td>{post.brandName}</td>
                <td>{post.price}</td>
                {/* <td>{post.quantity}</td>   */}
                <td>  
                <Link to="/" >  <button className="btn btn-success" >Buy</button> </Link> 
                  </td>  
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }
}
