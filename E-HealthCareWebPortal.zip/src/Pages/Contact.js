import React from "react";
export default function Contact() {
  
  
  return (
    <div className="contact">
    <div className="container"><br></br>
      <h2>Contact form</h2>
      <form class="form-horizontal"  action="/Contacts">
        <div>
          <label class="control-label col-sm-2" for="first" >
            FirstName:
          </label>
          <div class="col-sm-8">
            <input
              type="text"
              class="form-control"
              id="first"
              placeholder="Enter firstname"
              name="email"
              required
            />
          </div>
        </div><br></br>
        <div>
          <label class="control-label col-sm-2" for="email">
            Email:
          </label>
          <div class="col-sm-8">
            <input
              type="email"
              class="form-control"
              id="email"
              placeholder="Enter email"
              name="email"
              required
            />
          </div>
        </div><br></br>
        <div>
          <label class="control-label col-sm-2" for="email">
            Contact-Number:
          </label>
          <div class="col-sm-8">
            <input
              type="text"
              class="form-control"
              id="email"
              placeholder="Enter Mobile number"
              name="email"
              required
            />
          </div>
        </div><br></br>
        <div>
          <label class="control-label col-sm-2" for="dob">
            DOB:
          </label>
          <div class="col-sm-8">
            <input type="date" class="form-control" id="dob" name="email" required/>
          </div>
        </div><br></br>

        <div class="form-group">
          <div class="col-sm-offset-2 col-sm-10">
            <button
              type="submit"
              class="btn btn-default bg-black text-white mt-2">
              Submit
            </button>
          </div>
        </div>
      </form>
    </div>

    </div>   
  );
}
