import React from "react";
import axios from "axios";
import { Link } from "react-router-dom";

class Manageproducts extends React.Component {
  state = {  
    posts: []  
  }  
    
  componentDidMount() {  
    axios.get(`http://localhost:8080/health/getAll`)  
      .then(res => {  
        const posts = res.data;  
        this.setState({ posts });  
      })  
  }  
    
  deleteRow(id, e){  
    axios.delete(`https://jsonplaceholder.typicode.com/posts/${id}`)  
      .then(res => {  
        console.log(res);  
        console.log(res.data);  
    
        const posts = this.state.posts.filter(item => item.id !== id);  
        this.setState({ posts });  
      })  
    
  }  
    
  render() {  
    return (  
      <div class="bg">  
        <h2 class="f"> MANAGE PRODUCTS </h2> 
       <div class="success">
       
       <Link to="/AddNewMedicine"><button className="btn btn-success m-3" >ADD NEW MEDICINE</button></Link> 
       <Link to="/EditNewMedicine"><button className="btn btn-success" >EDIT MEDICINE</button></Link> 
        </div><br></br>
        <table className="table table-bordered">  
            <thead>  
              <tr>  
                  <th>ID</th>  
                  <th>MEDICINENAME</th>  
                  <th>BRANDNAME</th>  
                  <th>PRICE</th>
                  <th>QUANTITY</th>
                  <th>ACTION</th>  
              </tr>  
            </thead>  
    
            <tbody>  
              {this.state.posts.map((post) => (  
                <tr>  
                  <td>{post.id}</td>  
                  <td>{post.medicineName}</td>  
                  <td>{post.brandName}</td>  
                  <td>{post.price}</td>  
                  <td>{post.quantity}</td>  
                  <td>  
                    <button className="btn btn-danger" onClick={(e) => this.deleteRow(post.id, e)}>Delete</button>
                    
                  </td>  
                </tr>  
              ))}  
            </tbody>  
    
        </table>  
      </div>  
    )  
  }  
}

export default Manageproducts;