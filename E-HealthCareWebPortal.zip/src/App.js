import "./App.css";

import Navbar from "./Pages/Navbar";
import { Route, Routes } from "react-router";
import Homepage from "./Pages/Homepage";
import About from "./Pages/About";
import Contact from "./Pages/Contact";
import Viewproducts from "./Pages/Viewproducts";
import Manageproducts from "./Pages/manageproducts";
import Signup from "./Pages/Sign-up";
import Login from "./Pages/Login";
import Admin from "./Pages/Admin";
import Contacts from "./Pages/contactsuccess";
import AddNewMedicine from "./Pages/AddNewMedicine";
import EditNewMedicine from "./Pages/EditNewMedicine";
import Appointment from "./Pages/Appointment";
import BookSuccess from "./Pages/Booksuccess";


function App() {
  return (
    <div>
      <Navbar />

      <Routes>
        <Route path="/" element={<Homepage />} />
        <Route path="/About" element={<About />} />
        <Route path="/Contact" element={<Contact />} />
        <Route path="/Viewproducts" element={<Viewproducts />} />
        <Route path="/Signup" element={<Signup />} />
        <Route path="/Login" element={<Login />} />
        <Route path="/manageproducts" element={<Manageproducts/>}/>
        <Route path="/admin" element={<Admin/>} />
        <Route path="/contacts" element={<Contacts/>}/>
        <Route path="/addnewmedicine" element={<AddNewMedicine/>}/>
        <Route path="/editnewmedicine" element={<EditNewMedicine/>}/>
        <Route path="/appointment" element={<Appointment/>}/>
        <Route path="/Booksuccess" element={<BookSuccess/>}/>
        
      </Routes>
    </div>
  );
}

export default App;
